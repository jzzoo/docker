<?php

/*
 +--------------------------------------------------------------------------+
 | Zephir                                                                   |
 | Copyright (c) 2013-present Zephir Team (https://zephir-lang.com/)        |
 |                                                                          |
 | This source file is subject the MIT license, that is bundled with this   |
 | package in the file LICENSE, and is available through the world-wide-web |
 | at the following url: http://zephir-lang.com/license.html                |
 +--------------------------------------------------------------------------+
*/

namespace Zephir;

use Exception;

class ConfigException extends Exception
{
    public function __construct($message = "", $code = 0, Exception $previous = null)
    {
        $message .= PHP_EOL . "Please see http://zephir-lang.com/config.html for more information";

        parent::__construct($message, $code, $previous);
    }
}
