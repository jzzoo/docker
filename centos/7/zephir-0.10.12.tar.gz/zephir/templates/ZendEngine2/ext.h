
/* This file was generated automatically by Zephir do not modify it! */

#include "%PROJECT_LOWER_SAFE%.h"