<?php

function iconv($in_charset, $out_charset , $str)
{

}