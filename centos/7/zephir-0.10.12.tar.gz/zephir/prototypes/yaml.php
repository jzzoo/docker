<?php

function yaml_parse_file($filename, $pos = 0, &$ndocs = 0, $callbacks = null) {

}

function yaml_parse($data) {

}
