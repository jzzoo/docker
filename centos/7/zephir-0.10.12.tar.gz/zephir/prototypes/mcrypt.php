<?php

function mcrypt_list_algorithms()
{
}

function mcrypt_list_modes()
{
}
