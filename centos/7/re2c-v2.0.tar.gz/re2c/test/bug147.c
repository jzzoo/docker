bug147.re:3:10: error: undefined symbol 'name1'
