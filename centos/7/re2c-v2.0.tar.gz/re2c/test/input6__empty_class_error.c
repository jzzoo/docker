input6__empty_class_error.re:4:0: error: empty character class
