re2c: error: 're2c:eof' configuration is set, but no EOF rule found
