re2c: error: EOF exceeds maximum code unit value for given encoding
