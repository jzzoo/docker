eof/eof_08.re:3:25: error: configuration value overflow
