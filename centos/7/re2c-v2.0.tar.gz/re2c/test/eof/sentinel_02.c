re2c: error: sentinel exceeds maximum code unit value for given encoding
