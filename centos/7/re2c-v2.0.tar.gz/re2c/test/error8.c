error8.re:3:1: error: syntax error in octal escape sequence
