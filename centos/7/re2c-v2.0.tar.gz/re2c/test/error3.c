error3.re:19:4: error: unexpected character: ']'
