bug61.re:3:4: error: empty character class
