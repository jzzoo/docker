cpoint_class_error_eol.re:3:4: error: newline in character class
