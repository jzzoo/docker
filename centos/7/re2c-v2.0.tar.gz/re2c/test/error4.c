error4.re:3:1: error: syntax error in hexadecimal escape sequence
