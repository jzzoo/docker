error10.re:3:1: error: bad code point range: '0x900000 - 0x900000'
