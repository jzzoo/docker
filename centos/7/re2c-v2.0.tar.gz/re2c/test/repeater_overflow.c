repeater_overflow.re:3:4: error: repetition count overflow
