error12.re:4:16: error: trailing contexts are not allowed in named definitions
