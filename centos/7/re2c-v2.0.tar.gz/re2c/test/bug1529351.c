bug1529351.re:6:0: error: unexpected end of input
