extern const char *help;
const char *help = "";
