
. ../../__bench_utils.sh

compile http rfc7230 "--no-optimize-tags"
run_all http rfc7230

