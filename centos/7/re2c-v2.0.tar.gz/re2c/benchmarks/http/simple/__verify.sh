
. ../../__bench_utils.sh

verify http simple
